﻿var myPanel = (this instanceof Panel) ? this : new Window("palette", "Guchai", undefined, {resizeable:true});
myPanel.orientation = "column";


// Add a text input field for frequency
var freqGroup = myPanel.add("group");
freqGroup.add("statictext", undefined, "Frequency:");
var freqInput = freqGroup.add("edittext", [0, 0, 40, 20], "3");

// Add a button to apply expression
var applyButton = myPanel.add("button", undefined, "Apply");
// Add a button to remove expression
var removeButton = myPanel.add("button", undefined, "Remove");
 
 // Add logo image at the top
  var logoImage = myPanel.add("image", undefined, getResourceFile("icon.png"));
  logoImage.alignment = ["center", "bottom"]; // Align the logo image to the center and bottom

// Function to apply the expression
function applyExpression() {
  // Get the selected layer
  var selectedLayer = app.project.activeItem.selectedLayers[0];
  if (!selectedLayer) {
    alert("Please select a layer.");
    return;
  }
  
  // Get the frequency value from the input field
  var freq = parseFloat(freqInput.text);
  if (isNaN(freq) || freq <= 0) {
    alert("Please enter a valid positive number for frequency.");
    return;
  }
  
  // Set the expression on the selected layer's position, scale, and rotation properties with the updated values
  selectedLayer.property('Position').expression = "n = 0;\n"
    + "if (numKeys > 0){\n"
    + "  n = nearestKey(time).index;\n"
    + "  if (key(n).time > time) n--;\n"
    + "}\n"
    + "if (n == 0){\n"
    + "  t = 0;\n"
    + "}else{\n"
    + "  t = time - key(n).time;\n"
    + "}\n"
    + "if (n > 0 && t < 1){\n"
    + "  v = velocityAtTime(key(n).time - thisComp.frameDuration/10);\n"
    + "  amp = .06;\n"
    + "  freq = " + freq + ";\n"
    + "  decay = 5.0;\n"
    + "  value + v*amp*Math.sin(freq*t*2*Math.PI)/Math.exp(decay*t);\n"
    + "}else{\n"
    + "  value;\n"
    + "}";
    selectedLayer.property('Scale').expression = "n = 0;\n"
    + "if (numKeys > 0){\n"
    + "  n = nearestKey(time).index;\n"
    + "  if (key(n).time > time) n--;\n"
    + "}\n"
    + "if (n == 0){\n"
    + "  t = 0;\n"
    + "}else{\n"
    + "  t = time - key(n).time;\n"
    + "}\n"
    + "if (n > 0 && t < 1){\n"
    + "  v = velocityAtTime(key(n).time - thisComp.frameDuration/10);\n"
    + "  amp = .06;\n"
    + "  freq = " + freq + ";\n"
    + "  decay = 5.0;\n"
    + "  value + v*amp*Math.sin(freq*t*2*Math.PI)/Math.exp(decay*t);\n"
    + "}else{\n"
    + "  value;\n"
    + "}";
  selectedLayer.property('X Rotation').expression = selectedLayer.property('Y Rotation').expression = selectedLayer.property('Z Rotation').expression = "n = 0;\n"
    + "if (numKeys > 0){\n"
    + "  n = nearestKey(time).index;\n"
    + "  if (key(n).time > time) n--;\n"
    + "}\n"
    + "if (n == 0){\n"
    + "  t = 0;\n"
    + "}else{\n"
    + "  t = time - key(n).time;\n"
    + "}\n"
    + "if (n > 0 && t < 1){\n"
    + "  v = velocityAtTime(key(n).time - thisComp.frameDuration/10);\n"
    + "  amp = .06;\n"
    + "  freq = " + freq + ";\n"
    + "  decay = 5.0;\n"
    + "  value + v*amp*Math.sin(freq*t*2*Math.PI)/Math.exp(decay*t);\n"
    + "}else{\n"
    + "  value;\n"
    + "}";
}

// Function to remove the expression
function removeExpression() {
  // Get the selected layer
  var selectedLayer = app.project.activeItem.selectedLayers[0];
  if (!selectedLayer) {
    alert("Please select a layer.");
    return;
  }
  
  // Remove the expression from the selected layer's position property
  selectedLayer.property('Position').expression = "";
    // Remove the expression from the selected layer's scale property
  selectedLayer.property('Scale').expression = "";
    // Remove the expression from the selected layer's rotation property
   selectedLayer.property('X Rotation').expression = selectedLayer.property('Y Rotation').expression = selectedLayer.property('Z Rotation').expression = "";

}

// Set the action for the buttons
applyButton.onClick = applyExpression;
removeButton.onClick = removeExpression;

// Function to get resource file path
  function getResourceFile(filename) {
    var scriptFolder = Folder($.fileName).parent;
    var resourcePath = scriptFolder.fullName + "/Lafai icon/" + filename;
    return new File(resourcePath);
    }


// Show the UI panel

// Show the panel
if (myPanel instanceof Window) {
myPanel.center();
myPanel.show();

} else {
myPanel.layout.layout(true);
myPanel.layout.resize();
}



