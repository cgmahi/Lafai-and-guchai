Thanks for downloading my script. 

How to install

C:\Program Files\Adobe\Adobe After Effects 2023\Support Files\Scripts\ScriptUI Panels

Guchai icon and jsx file paste it into ScriptUI Panels.
Lafai icon and jsx file paste it into ScriptUI Panels.

If you have any query feel free to send me a mail:mahibubt@gmail.com

Want to donate? 
Bkash: 01623492257
Nagad: 01623492257
Rocket: 016234922571


