﻿

// Create a dockable panel
var myPanel = (this instanceof Panel) ? this : new Window("palette", "Guchai", undefined, {resizeable:true});
myPanel.orientation = "column";
 

  // Create a group for logo and button
  var group = myPanel.add("group");
  group.orientation = "column";
  group.alignChildren = "center";

  // Create a container group for the button with vertical alignment
  var buttonContainer = group.add("group");
  buttonContainer.orientation = "column";
  buttonContainer.alignChildren = "center";

  // UI Elements
var btnMoveAssets = myPanel.add("button", undefined, "Guchai");
btnMoveAssets.size = [78, 30];
 // Add logo image at the top
  var logoImage = myPanel.add("image", undefined, getResourceFile("gucai.png"));
  logoImage.alignment = ["center", "bottom"]; // Align the logo image to the center and bottom


// Event Listeners
btnMoveAssets.onClick = moveAssets;
 // Resize Event Listener
  myPanel.onResizing = myPanel.onResize = function() {
    var panelWidth = myPanel.size[0];
    btnMoveAssets.size = [panelWidth - 20, 30];
   
    // Adjust the size of the button based on the panel width
    var buttonWidth = Math.min(panelWidth - 40, 80); // Adjust the maximum width of the button
    btnMoveAssets.size[0] = buttonWidth;
  };


 
// Function to move assets
function moveAssets() {
  var project = app.project;
  var imageExtensions = ["ai", "eps", "png", "jpg", "jpeg", "gif"];
  var videoExtensions = ["mov", "mp4", "avi"];
  var audioExtensions = ["wav", "mp3"];

  // Check if destination folders already exist
  var imageFolder = findFolderByName("Image Assets");
  var videoFolder = findFolderByName("Video Assets");
  var audioFolder = findFolderByName("Audio Assets");
  var precompFolder = findFolderByName("All Precomps");
   

  // Create the destination folders if they don't exist
  if (!imageFolder) {
    imageFolder = project.items.addFolder("Image Assets");
  }
  if (!videoFolder) {
    videoFolder = project.items.addFolder("Video Assets");
  }
  if (!audioFolder) {
    audioFolder = project.items.addFolder("Audio Assets");
  }
  if (!precompFolder) {
    precompFolder = project.items.addFolder("All Precomps");
  }

  // Array to store items that need to be moved
  var itemsToMove = [];

  // Loop through project items
  for (var i = 1; i <= project.numItems; i++) {
    var item = project.item(i);

    // Check if item is a Footage item and has a file associated with it
    if (item instanceof FootageItem && item.file) {
      var fileExtension = item.file.name.substring(item.file.name.lastIndexOf(".") + 1);

      // Check if file extension matches image extensions
      if (imageExtensions.indexOf(fileExtension.toLowerCase()) !== -1) {
        // Add item to the itemsToMove array with destination folder
        itemsToMove.push({ item: item, destinationFolder: imageFolder });
      }
      // Check if file extension matches video extensions
      else if (videoExtensions.indexOf(fileExtension.toLowerCase()) !== -1) {
        // Add item to the itemsToMove array with destination folder
        itemsToMove.push({ item: item, destinationFolder: videoFolder });
      }
      // Check if file extension matches audio extensions
      else if (audioExtensions.indexOf(fileExtension.toLowerCase()) !== -1) {
        // Add item to the itemsToMove array with destination folder
        itemsToMove.push({ item: item, destinationFolder: audioFolder });
      }
    }
    // Check if item is a precomp
    else if (item instanceof CompItem) {
      // Add precomp to the itemsToMove array with destination folder
      itemsToMove.push({ item: item, destinationFolder: precompFolder });
    }
  }

  // Move the items to the destination folders
  for (var j = 0; j < itemsToMove.length; j++) {
    var itemToMove = itemsToMove[j].item;
    var destinationFolder = itemsToMove[j].destinationFolder;
    itemToMove.parentFolder = destinationFolder;
  }

  // Show a message when the process is completed
  alert("Asset move process completed successfully!");
}
 // Function to get resource file path
  function getResourceFile(filename) {
    var scriptFolder = Folder($.fileName).parent;
    var resourcePath = scriptFolder.fullName + "/Guchai Icon/" + filename;
    return new File(resourcePath);
    }
// Function to find folder
function findFolderByName(folderName) {
var project = app.project;
for (var i = 1; i <= project.numItems; i++) {
var item = project.item(i);
if (item instanceof FolderItem && item.name === folderName) {
return item;
}
}
return null;
}

// Show the panel
if (myPanel instanceof Window) {
myPanel.center();
myPanel.show();
} else {
myPanel.layout.layout(true);
myPanel.layout.resize();
}
